#ifndef __IOI2C_H
#define __IOI2C_H
#include "msp430.h"
#include <stdint.h>
//����Ӳ�����죬��I2C��IO�ڲ������к궨��
#define I2C_CLK_HIGH            P6DIR &=~BIT5;
#define I2C_CLK_LOW             P6DIR |= BIT5; P6OUT &=~BIT5
#define I2C_DATA_HIGH       P6DIR &=~BIT6
#define I2C_DATA_LOW        P6DIR |= BIT6; P6OUT &=~BIT6
#define READ_SDA         P6IN&BIT6

//IIC���в�������
void I2C_Init(void);                //��ʼ��IIC��IO��
int I2C_Start(void);				//����IIC��ʼ�ź�
void I2C_Stop(void);	  			//����IICֹͣ�ź�
void I2C_Send_Byte(unsigned char txd);			//IIC����һ���ֽ�
unsigned char I2C_Read_Byte(unsigned char ack);//IIC��ȡһ���ֽ�
int I2C_Wait_Ack(void); 				//IIC�ȴ�ACK�ź�
void I2C_Ack(void);					//IIC����ACK�ź�
void I2C_NAck(void);				//IIC������ACK�ź�

void I2C_Write_One_Byte(unsigned char daddr,unsigned char addr,unsigned char data);
unsigned char I2C_Read_One_Byte(unsigned char daddr,unsigned char addr);
unsigned char I2C_Readkey(unsigned char I2C_Addr);

unsigned char I2C_ReadOneByte(unsigned char I2C_Addr,unsigned char addr);
unsigned char IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
unsigned char IICwriteBytes(unsigned char dev, unsigned char reg, unsigned char length, unsigned char* data);
unsigned char IICwriteBits(unsigned char dev,unsigned char reg,unsigned char bitStart,unsigned char length,unsigned char data);
unsigned char IICwriteBit(unsigned char dev,unsigned char reg,unsigned char bitNum,unsigned char data);
unsigned char IICreadBytes(unsigned char dev, unsigned char reg, unsigned char length, unsigned char *data);

int i2cWrite(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *data);
int i2cRead(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf);

#endif

//------------------End of File----------------------------
